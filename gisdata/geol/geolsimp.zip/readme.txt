Simplified Geology of Madagascar

This Archive contains:

GEOLSIMP DBF       323,549  12/12/97  14:41 geolsimp.dbf - ArcView Shape File (Attributes)
GEOLSIMP SHP     1,848,388  12/12/97  14:41 geolsimp.shp - ArcView Shape File 
GEOLSIMP SHX         8,108  12/12/97  14:41 geolsimp.shx - ArcView Shape File (index)
GEOLSIMP MET        12,645  15/12/97  12:40 geolsimp.met - MetaData in Text format (Please Read)
GEOLSIMP HTM        20,794  16/12/97  12:22 geolsimp.html - MetaData in html format
GEOLSIMP AVL         5,458  16/12/97  15:09 geolsimp.avl - ArcView Legend file
GEOLSI~1 SGM        11,530  16/12/97  12:22 geolsimp.sgml - MetaData in sgml format
GEOLSLAR GIF       144,889  01/10/97  12:33 geolslar.gif - Browse graphic very large
GEOLSMED GIF        37,868  06/10/97  13:17 geolsmed.gif - Browse graphic Medium
GEOLSTHB GIF        12,762  06/10/97  16:39 geolsthb.gif -  Browse graphic Thumb Nail
Readme.txt - This file.

Justin Moat,
GIS Scientist,
Malagasy Plant Diversity Project
Royal Botanic Gardens,
Kew,
Richmond, 
Surrey,TW9 3AB.
United Kingdom.
Tel: +44 (0)181 332 5237      
Fax: +44 (0)181 332 5278    
e-mail J.Moat@rbgkew.org.uk